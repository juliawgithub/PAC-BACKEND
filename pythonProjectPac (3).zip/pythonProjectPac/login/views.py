from django.shortcuts import render, redirect

from plano.models import Plano
from .forms import LoginForm

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login_success')
    else:
        form = LoginForm()
    return render(request, 'login/login.html', {'form': form})

def login_success(request):
    # Recuperar o usuário logado
    user = request.user

    # Verificar se o usuário tem um município associado
    if user.is_authenticated and hasattr(user, 'login'):
        municipio = user.login.municipio

        # Recuperar os planos associados ao município do usuário
        planos = Plano.objects.filter(municipio=municipio)

        return render(request, 'login/dashboard.html', {'planos': planos})
    else:
        # Caso o usuário não esteja autenticado ou não tenha um município associado
        return render(request, 'error.html', {'message': 'Usuário não autenticado ou município não encontrado'})