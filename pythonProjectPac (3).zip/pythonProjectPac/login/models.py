from django.db import models

class Login(models.Model):
    entidade = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    senha = models.CharField(max_length=100)
    municipio = models.CharField(max_length=100, blank=True, null=True)  # Adicionando o campo 'municipio'

    def __str__(self):
        return self.email
